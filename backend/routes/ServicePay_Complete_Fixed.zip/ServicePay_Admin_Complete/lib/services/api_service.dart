import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class ApiService {

  static Future<Map<String, dynamic>> buyAirtime({
    required String network,
    required String phone,
    required String amount,
  }) async {
    final response = await http.post(
      Uri.parse("${ApiConfig.baseUrl}/clubkonnect/airtime"),
      headers: {
        "Content-Type": "application/json",
      },
      body: jsonEncode({
        "network": network,
        "phone": phone,
        "amount": amount,
      }),
    );

    return jsonDecode(response.body);
  }
}