class ApiConfig {
  ApiConfig._();

  // Override during build with:
  // flutter build apk --release --dart-define=API_BASE_URL=https://api.servicepay.ng/api
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://silver-space-orbit-wxw9x9rjrqx2ggr4-3000.app.github.dev/api',
  );
}
