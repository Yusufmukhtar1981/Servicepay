import 'package:flutter/material.dart';

import 'login_screen.dart';

void main() {
  runApp(const ServicepayApp());
}

class ServicepayApp extends StatelessWidget {
  const ServicepayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Servicepay',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.green,
        ),
        useMaterial3: true,
      ),
      home: const LoginScreen(),
    );
  }
}