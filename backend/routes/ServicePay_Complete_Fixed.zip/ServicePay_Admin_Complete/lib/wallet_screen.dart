import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'config/api_config.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {

  final amountController = TextEditingController();

  bool isLoading = false;
  bool isRefreshing = true;
  double walletBalance = 0;
  List<Map<String, dynamic>> transactions = [];

  @override
  void initState() {
    super.initState();
    refreshWallet();
  }

  @override
  void dispose() {
    amountController.dispose();
    super.dispose();
  }

  void showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  Future<void> refreshWallet() async {
    if (mounted) setState(() => isRefreshing = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');

      if (token == null || token.isEmpty) {
        showMessage('Please login again.');
        return;
      }

      final responses = await Future.wait([
        http.get(
          Uri.parse('${ApiConfig.baseUrl}/wallet'),
          headers: {'Authorization': 'Bearer $token'},
        ),
        http.get(
          Uri.parse('${ApiConfig.baseUrl}/wallet/history?limit=30'),
          headers: {'Authorization': 'Bearer $token'},
        ),
      ]);

      final walletResult = jsonDecode(responses[0].body);
      final historyResult = jsonDecode(responses[1].body);

      if (responses[0].statusCode == 200 && walletResult['success'] == true) {
        final data = walletResult['data'];
        final newBalance =
            num.tryParse(data?['walletBalance']?.toString() ?? '0') ?? 0;
        await prefs.setDouble('wallet_balance', newBalance.toDouble());

        if (mounted) {
          setState(() => walletBalance = newBalance.toDouble());
        }
      } else {
        throw Exception(walletResult['message'] ?? 'Unable to load wallet.');
      }

      if (responses[1].statusCode == 200 && historyResult['success'] == true) {
        final data = historyResult['data'];
        if (mounted) {
          setState(() {
            transactions = data is List
                ? data.whereType<Map<String, dynamic>>().toList()
                : [];
          });
        }
      }
    } catch (error) {
      final prefs = await SharedPreferences.getInstance();
      final savedBalance = prefs.getDouble('wallet_balance') ?? 0;
      if (mounted) setState(() => walletBalance = savedBalance);
      showMessage(error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => isRefreshing = false);
    }
  }

  Future<void> fundWallet() async {
    final amount = double.tryParse(amountController.text.trim());

    if (amount == null || amount < 100) {
      showMessage('Minimum wallet funding is ₦100.');
      return;
    }

    setState(() => isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('auth_token');
      final email = prefs.getString('user_email');

      if (token == null || token.isEmpty || email == null || email.isEmpty) {
        showMessage('Please login again.');
        return;
      }

      final response = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/paystack/initialize'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'email': email, 'amount': amount}),
      );

      final result = jsonDecode(response.body);
      final serverMessage =
          result['message']?.toString() ?? 'Unable to initialize payment.';

      if (response.statusCode == 200 && result['success'] == true) {
        final authorizationUrl = result['authorizationUrl']?.toString() ?? '';
        if (authorizationUrl.isEmpty) {
          showMessage('Payment link was not returned.');
          return;
        }

        final opened = await launchUrl(
          Uri.parse(authorizationUrl),
          mode: LaunchMode.platformDefault,
        );

        if (!opened) {
          showMessage('Unable to open Paystack payment page.');
        }
      } else {
        showMessage(serverMessage);
      }
    } on FormatException {
      showMessage('Server returned an invalid response.');
    } on http.ClientException {
      showMessage('Unable to connect to ServicePay server.');
    } catch (error) {
      showMessage(error.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  String formatDate(dynamic value) {
    final date = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
    if (date == null) return '';
    String two(int number) => number.toString().padLeft(2, '0');
    return '${two(date.day)}/${two(date.month)}/${date.year} ${two(date.hour)}:${two(date.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('Wallet'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        actions: [
          IconButton(onPressed: refreshWallet, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: refreshWallet,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  const Text('Wallet Balance', style: TextStyle(color: Colors.white70, fontSize: 16)),
                  const SizedBox(height: 8),
                  isRefreshing
                      ? const Padding(
                          padding: EdgeInsets.all(8),
                          child: CircularProgressIndicator(color: Colors.white),
                        )
                      : Text(
                          '₦${walletBalance.toStringAsFixed(2)}',
                          style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
                        ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'Amount',
                prefixText: '₦ ',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 52,
              child: ElevatedButton(
                onPressed: isLoading ? null : fundWallet,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: isLoading
                    ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                    : const Text('Fund Wallet', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 28),
            const Text('Recent Transactions', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            if (!isRefreshing && transactions.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: Text('No transactions yet')),
                ),
              ),
            ...transactions.map((item) {
              final isCredit = item['direction'] == 'CREDIT';
              final amount = num.tryParse(item['amount']?.toString() ?? '0') ?? 0;
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: isCredit ? Colors.green.shade50 : Colors.red.shade50,
                    child: Icon(isCredit ? Icons.south_west : Icons.north_east, color: isCredit ? Colors.green : Colors.red),
                  ),
                  title: Text(item['title']?.toString() ?? 'Transaction', style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('${item['description'] ?? ''}\n${formatDate(item['createdAt'])}'),
                  isThreeLine: true,
                  trailing: Text(
                    '${isCredit ? '+' : '-'}₦${amount.toStringAsFixed(2)}',
                    style: TextStyle(fontWeight: FontWeight.bold, color: isCredit ? Colors.green : Colors.red),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
