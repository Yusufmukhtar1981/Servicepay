const mongoose = require('mongoose');
const auditLogSchema = new mongoose.Schema({
  admin: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  action: { type: String, required: true, trim: true },
  targetType: { type: String, default: null },
  targetId: { type: String, default: null },
  details: { type: mongoose.Schema.Types.Mixed, default: null },
  ipAddress: { type: String, default: null },
}, { timestamps: true });
module.exports = mongoose.model('AuditLog', auditLogSchema);
