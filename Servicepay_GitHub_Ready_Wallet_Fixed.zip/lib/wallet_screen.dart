import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  static const String baseUrl = 'https://api.servicepay.ng/api';

  final TextEditingController amountController = TextEditingController();
  final TextEditingController referenceController = TextEditingController();

  bool isLoading = false;
  bool isRefreshing = false;
  double walletBalance = 0;
  List<Map<String, dynamic>> history = [];

  @override
  void initState() {
    super.initState();
    _loadWalletData();
  }

  @override
  void dispose() {
    amountController.dispose();
    referenceController.dispose();
    super.dispose();
  }

  void showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<Map<String, String>> authHeaders() async {
    final preferences = await SharedPreferences.getInstance();
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ${preferences.getString('auth_token') ?? ''}',
    };
  }

  Future<void> _loadWalletData() async {
    if (mounted) setState(() => isRefreshing = true);
    await Future.wait([refreshWallet(), refreshHistory()]);
    if (mounted) setState(() => isRefreshing = false);
  }

  Future<void> refreshWallet() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/wallet'),
        headers: await authHeaders(),
      );
      final json = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 200 && json['success'] == true) {
        final data = json['data'] as Map<String, dynamic>;
        final balance =
            (num.tryParse(data['walletBalance'].toString()) ?? 0).toDouble();
        final preferences = await SharedPreferences.getInstance();
        await preferences.setDouble('wallet_balance', balance);
        if (mounted) setState(() => walletBalance = balance);
      }
    } catch (_) {
      final preferences = await SharedPreferences.getInstance();
      if (mounted) {
        setState(() {
          walletBalance = preferences.getDouble('wallet_balance') ?? 0;
        });
      }
    }
  }

  Future<void> refreshHistory() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/wallet/history?limit=20'),
        headers: await authHeaders(),
      );
      final json = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 200 && json['success'] == true) {
        final items = (json['data'] as List<dynamic>? ?? [])
            .map((item) => Map<String, dynamic>.from(item as Map))
            .toList();
        if (mounted) setState(() => history = items);
      }
    } catch (_) {
      // Keep the current history visible if refresh fails.
    }
  }

  Future<void> initializeFunding() async {
    final amount = double.tryParse(amountController.text.trim());
    if (amount == null || amount < 100) {
      showMessage('Minimum wallet funding is ₦100.');
      return;
    }

    setState(() => isLoading = true);
    try {
      final preferences = await SharedPreferences.getInstance();
      final response = await http.post(
        Uri.parse('$baseUrl/paystack/initialize'),
        headers: await authHeaders(),
        body: jsonEncode({
          'email': preferences.getString('user_email'),
          'amount': amount,
        }),
      );
      final json = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 200 && json['success'] == true) {
        referenceController.text = json['reference']?.toString() ?? '';
        final paymentUrl = Uri.tryParse(json['authorizationUrl'].toString());
        if (paymentUrl == null ||
            !await launchUrl(
              paymentUrl,
              mode: LaunchMode.externalApplication,
            )) {
          showMessage('Unable to open the Paystack payment page.');
          return;
        }
        showMessage(
          'Complete the payment, return to ServicePay, then tap Verify Payment.',
        );
      } else {
        showMessage(json['message']?.toString() ?? 'Unable to start payment.');
      }
    } catch (_) {
      showMessage('Unable to connect to the ServicePay server.');
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> verifyFunding() async {
    final reference = referenceController.text.trim();
    if (reference.isEmpty) {
      showMessage('Start a wallet payment first or enter its reference.');
      return;
    }

    setState(() => isLoading = true);
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/paystack/verify'),
        headers: await authHeaders(),
        body: jsonEncode({'reference': reference}),
      );
      final json = jsonDecode(response.body) as Map<String, dynamic>;
      showMessage(json['message']?.toString() ?? 'Verification completed.');

      if (response.statusCode == 200 && json['success'] == true) {
        await _loadWalletData();
        amountController.clear();
      }
    } catch (_) {
      showMessage('Unable to verify payment. Check your connection and retry.');
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  String _formatDate(dynamic rawDate) {
    final date = DateTime.tryParse(rawDate?.toString() ?? '')?.toLocal();
    if (date == null) return '';
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '$day/$month/${date.year} $hour:$minute';
  }

  Widget _historyItem(Map<String, dynamic> item) {
    final isCredit = item['direction'] == 'CREDIT';
    final amount =
        (num.tryParse(item['amount']?.toString() ?? '0') ?? 0).toDouble();
    final status = item['status']?.toString() ?? '';

    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(
        backgroundColor: isCredit ? Colors.green.shade50 : Colors.red.shade50,
        child: Icon(
          isCredit ? Icons.arrow_downward : Icons.arrow_upward,
          color: isCredit ? Colors.green : Colors.red,
        ),
      ),
      title: Text(item['title']?.toString() ?? 'Transaction'),
      subtitle: Text(
        '${item['description'] ?? ''}\n${_formatDate(item['createdAt'])} · $status',
      ),
      isThreeLine: true,
      trailing: Text(
        '${isCredit ? '+' : '-'}₦${amount.toStringAsFixed(2)}',
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: isCredit ? Colors.green : Colors.red,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wallet'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: isRefreshing ? null : _loadWalletData,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadWalletData,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  const Text(
                    'Wallet Balance',
                    style: TextStyle(color: Colors.white70),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '₦${walletBalance.toStringAsFixed(2)}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Fund Wallet',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: amountController,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Funding amount',
                prefixText: '₦ ',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 14),
            ElevatedButton(
              onPressed: isLoading ? null : initializeFunding,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.all(16),
              ),
              child: Text(isLoading ? 'Please wait...' : 'Continue with Paystack'),
            ),
            const SizedBox(height: 24),
            const Text(
              'Verify Completed Payment',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: referenceController,
              decoration: const InputDecoration(
                labelText: 'Paystack reference',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: isLoading ? null : verifyFunding,
              icon: const Icon(Icons.verified_outlined),
              label: const Text('Verify Payment and Update Wallet'),
            ),
            const SizedBox(height: 28),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Recent Transactions',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                if (isRefreshing)
                  const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            if (history.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: Text('No transactions yet.')),
              )
            else
              ...history.map(_historyItem),
          ],
        ),
      ),
    );
  }
}
