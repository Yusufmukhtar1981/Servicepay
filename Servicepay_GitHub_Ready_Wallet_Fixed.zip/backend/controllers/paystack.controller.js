const axios = require("axios");
const User = require("../models/user.model");
const Transaction = require("../models/transaction.model");

const getPaystackKey = () => {
  const key = String(process.env.PAYSTACK_SECRET_KEY || "").trim();
  if (!key.startsWith("sk_")) {
    const error = new Error("Paystack is not configured correctly.");
    error.statusCode = 500;
    throw error;
  }
  return key;
};

exports.initializePayment = async (req, res) => {
  try {
    const email = String(req.user?.email || req.body.email || "")
      .trim()
      .toLowerCase();
    const amount = Number(req.body.amount);

    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Add a valid email address to your ServicePay account first.",
      });
    }

    if (!Number.isFinite(amount) || amount < 100) {
      return res.status(400).json({
        success: false,
        message: "Minimum wallet funding is ₦100.",
      });
    }

    const key = getPaystackKey();
    const amountInKobo = Math.round(amount * 100);
    const userId = String(req.user._id || req.user.id);

    const response = await axios.post(
      "https://api.paystack.co/transaction/initialize",
      {
        email,
        amount: amountInKobo,
        metadata: {
          userId,
          purpose: "WALLET_FUNDING",
          expectedAmountKobo: amountInKobo,
        },
      },
      {
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
        },
        timeout: 30000,
      }
    );

    const data = response.data.data;
    return res.status(200).json({
      success: true,
      message: "Payment initialized successfully.",
      authorizationUrl: data.authorization_url,
      accessCode: data.access_code,
      reference: data.reference,
    });
  } catch (error) {
    return res.status(error.statusCode || error.response?.status || 500).json({
      success: false,
      message:
        error.response?.data?.message ||
        error.message ||
        "Unable to initialize payment.",
    });
  }
};

exports.verifyPayment = async (req, res) => {
  const reference = String(req.body.reference || "").trim();
  const userId = String(req.user._id || req.user.id);

  try {
    if (!reference) {
      return res.status(400).json({
        success: false,
        message: "Payment reference is required.",
      });
    }

    const previous = await Transaction.findOne({
      reference,
      serviceType: "WALLET_FUNDING",
    }).lean();

    if (previous) {
      if (String(previous.customerId) !== userId) {
        return res.status(403).json({
          success: false,
          message: "This payment belongs to another account.",
        });
      }

      const currentUser = await User.findById(userId).select("walletBalance");
      return res.status(200).json({
        success: true,
        message:
          previous.status === "SUCCESSFUL"
            ? "Payment was already verified."
            : "Payment verification is already being processed.",
        walletBalance: Number(currentUser?.walletBalance || 0),
        reference,
      });
    }

    const key = getPaystackKey();
    const response = await axios.get(
      `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
      {
        headers: { Authorization: `Bearer ${key}` },
        timeout: 30000,
      }
    );

    const payment = response.data.data;
    if (!payment || payment.status !== "success") {
      return res.status(400).json({
        success: false,
        message: "Payment has not been completed successfully.",
      });
    }

    if (
      payment.metadata?.purpose &&
      payment.metadata.purpose !== "WALLET_FUNDING"
    ) {
      return res.status(400).json({
        success: false,
        message: "This reference is not for wallet funding.",
      });
    }

    if (
      payment.metadata?.userId &&
      String(payment.metadata.userId) !== userId
    ) {
      return res.status(403).json({
        success: false,
        message: "This payment does not belong to your account.",
      });
    }

    const amountInKobo = Number(payment.amount);
    const amount = amountInKobo / 100;

    if (!Number.isSafeInteger(amountInKobo) || amountInKobo < 10000) {
      return res.status(400).json({
        success: false,
        message: "Invalid payment amount returned by Paystack.",
      });
    }

    if (
      payment.metadata?.expectedAmountKobo &&
      Number(payment.metadata.expectedAmountKobo) !== amountInKobo
    ) {
      return res.status(400).json({
        success: false,
        message: "The paid amount does not match the initialized amount.",
      });
    }

    // Create the unique funding record before crediting the wallet. This makes
    // repeated Verify requests idempotent and prevents duplicate wallet credit.
    let transaction;
    try {
      transaction = await Transaction.create({
        reference,
        customerId: userId,
        agentId: req.user.agentId || null,
        stateManagerId: req.user.stateManagerId || null,
        zonalManagerId: req.user.zonalManagerId || null,
        serviceType: "WALLET_FUNDING",
        provider: "PAYSTACK",
        amount,
        status: "PENDING",
        providerResponse: payment,
      });
    } catch (error) {
      if (error?.code === 11000) {
        const currentUser = await User.findById(userId).select("walletBalance");
        return res.status(200).json({
          success: true,
          message: "Payment verification is already being processed.",
          walletBalance: Number(currentUser?.walletBalance || 0),
          reference,
        });
      }
      throw error;
    }

    try {
      const user = await User.findByIdAndUpdate(
        userId,
        {
          $inc: {
            walletBalance: amount,
            totalTransactions: 1,
          },
        },
        { new: true, runValidators: true }
      ).select("walletBalance");

      if (!user) {
        throw new Error("User account not found.");
      }

      transaction.status = "SUCCESSFUL";
      await transaction.save();

      return res.status(200).json({
        success: true,
        message: `₦${amount.toFixed(2)} has been added to your wallet.`,
        walletBalance: Number(user.walletBalance || 0),
        reference,
      });
    } catch (creditError) {
      transaction.status = "FAILED";
      transaction.providerResponse = {
        payment,
        walletCreditError: creditError.message,
      };
      await transaction.save().catch(() => {});
      throw creditError;
    }
  } catch (error) {
    return res.status(error.statusCode || error.response?.status || 500).json({
      success: false,
      message:
        error.response?.data?.message ||
        error.message ||
        "Unable to verify payment.",
    });
  }
};
